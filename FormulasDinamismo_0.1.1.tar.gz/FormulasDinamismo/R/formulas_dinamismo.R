
calc_distancia <-function (tiempo, velocidad) 
{
  #calcula distancia recorrida
  distancia <- tiempo * velocidad
  distancia
}

calc_tiempo <-function(distancia, velocidad)
{
  #calcula el tiempo que ha tardado en recorrer una distancia
  tiempo <- distancia / velocidad
  tiempo
}

calc_velocidad <- function(distancia, tiempo)
{
  #calcula la velocidad  a la que se recorr�a un tramo
  velocidad <-distancia/tiempo
  velocidad
}
